# taskara/__init__.py
from taskara.taskara import Taskara
