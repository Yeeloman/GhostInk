from taskara import Taskara


t = Taskara(log_to_file=True)

t.add_task("first task")
t.print()
